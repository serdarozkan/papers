Figure 2, 4, 5, 6: AggStatWage7811.do
Figure 7, 8, 9, 10, 11: YRCHNGE_main_wage_yr_7811.do and YRCHNGE_wage_7811.do
Figure 13, 14, 15: DJMP_DP_main_wage.do and DJMP_DP_short.do
Figure 16: YRCHNGE_top1p_main_wage_yr_7811.do and YRCHNGE_top1p_7811.do